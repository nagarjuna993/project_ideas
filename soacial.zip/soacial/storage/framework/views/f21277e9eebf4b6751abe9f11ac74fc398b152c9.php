<?php echo $__env->make('template.notifier', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(!$users->count()): ?>
            <div class="text-center">
                <h3 style="color: black;">You have no pending requests</h3>
            </div>
        <?php else: ?>
            <div class="row" style="display:flex; flex-wrap: wrap;">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <div class="col-md-3 col-sm-4">
                        <div class="thumbnail">
                            <?php if(!is_null($user->usersInfo->avatar)): ?>
                                <a href="<?php echo e(route('profile',['regno' => $user->reg_no])); ?>">
                                    <img src="<?php echo e(asset('/uploads/avatars/'.$user->usersInfo->user_regno.'/'.$user->usersInfo->avatar)); ?>"/>
                                </a>
                            <?php elseif($user->gender == 'Male'): ?>
                                <a href="<?php echo e(route('profile',['regno' => $user->reg_no])); ?>">
                                    <img src="<?php echo e(asset('/uploads/avatars/default_male.jpg')); ?>"/>
                                </a>
                            <?php else: ?>
                                <a href="<?php echo e(route('profile',['regno' => $user->reg_no])); ?>">
                                    <img src="<?php echo e(asset('/uploads/avatars/default_female.jpg')); ?>"/>
                                </a>
                            <?php endif; ?>

                            <?php if($user->reg_no == 1441012011): ?>
                                <div class="label label-info" style="display:block;">Founder</div>
                            <?php endif; ?>

                            <div class="caption text-center">
                                <strong style="font-size: 20px"><?php echo e($user->full_name); ?></strong>
                                <h6><?php echo e($user->usersInfo->academicYear_from); ?> - <?php echo e($user->usersInfo->academicYear_to); ?></h6>
                                <h6><?php echo e($user->institutes->name); ?></h6>



                                <a href="<?php echo e(route('profile',['regno' => $user->reg_no])); ?>" class="btn btn-primary btn-xs" role="button" style="border-radius:50px"><i class="fa fa-user-circle" aria-hidden="true"></i> Profile</a>

                                

                                <?php if(!Auth::user()->pendingRequests->contains($user->id) && $user->pendingRequests->contains(Auth::user()->id)): ?>

                                    <div class="btn-group">
                                        <a href="#" class="btn btn-default btn-xs dropdown-toggle" style="border-radius:50px;" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                            <i class="fa fa-clock-o" aria-hidden="true"></i> Request Pending <span class="caret"></span>
                                        </a>
                                        <ul class="dropdown-menu pendingRequestBtn">
                                            <li><a href="<?php echo e(route('pendingRequest',['regno' => $user->reg_no, 'accept' => true])); ?>">Accept</a></li>
                                            <li><a href="<?php echo e(route('pendingRequest',['regno' => $user->reg_no, 'accept' => false])); ?>">Reject</a></li>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
    <div class="container text-center">
        <?php echo e($users->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>