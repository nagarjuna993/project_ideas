<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="thumbnail">
                    <?php if(!is_null($user->usersInfo->avatar)): ?>
                        <?php if($user->approvedRequests->contains(Auth::user()->id) || Auth::user()->approvedRequests->contains($user->id) || Auth::user()->reg_no == $user->reg_no): ?>
                        <a href="#"><img class="dp" src="<?php echo e(asset('/uploads/avatars/'.$user->usersInfo->user_regno.'/'.$user->usersInfo->avatar)); ?>"/></a>
                        <?php else: ?>
                            <img src="<?php echo e(asset('/uploads/avatars/'.$user->usersInfo->user_regno.'/'.$user->usersInfo->avatar)); ?>"/>
                        <?php endif; ?>
                    <?php elseif($user->gender == 'Male'): ?>
                        <img src="<?php echo e(asset('/uploads/avatars/default_male.jpg')); ?>"/>
                    <?php else: ?>
                        <img src="<?php echo e(asset('/uploads/avatars/default_female.jpg')); ?>"/>
                    <?php endif; ?>
                    <div class="caption text-center">
                        <strong style="font-size: 25px;"><?php echo e($user->full_name); ?></strong>
                    </div>

                    <?php if($user->reg_no == 1441012011): ?>
                        <div class="label label-info" style="display:block;"></div>
                    <?php endif; ?>

                </div>
                <?php if(!Auth::user()->pendingRequests->contains($user->id) && !$user->pendingRequests->contains(Auth::user()->id) && !$user->approvedRequests->contains(Auth::user()->id) && !Auth::user()->approvedRequests->contains($user->id)): ?>
                    <?php if(Auth::user()->reg_no != $user->reg_no): ?>
                    <a href="<?php echo e(route('addFriend',['regno' => $user->reg_no])); ?>" class="btn btn-default btn-xs friendBtn" role="button" style="border-radius:50px">
                        <i class="fa fa-user-plus" aria-hidden="true"></i> Add Friend
                    </a>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if(Auth::user()->pendingRequests->contains($user->id)): ?>
                    <a href="#" class="btn btn-default btn-xs disabled" role="button" style="border-radius:50px; cursor:default;">
                        <i class="fa fa-thumbs-up" aria-hidden="true"></i> Request Sent
                    </a>
                <?php endif; ?>
                <?php if($user->pendingRequests->contains(Auth::user()->id)): ?>
                    <div class="btn-group">
                        <a href="#" class="btn btn-default btn-xs dropdown-toggle" style="border-radius:50px;" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            <i class="fa fa-clock-o" aria-hidden="true"></i>
                            Request Pending <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu pendingRequestBtn">
                            <li><a href="<?php echo e(route('pendingRequest',['regno' => $user->reg_no, 'accept' => true])); ?>">Accept</a></li>
                            <li><a href="<?php echo e(route('pendingRequest',['regno' => $user->reg_no, 'accept' => false])); ?>">Reject</a></li>
                        </ul>
                    </div>
                <?php endif; ?>
                <?php if(Auth::user()->approvedRequests->contains($user->id) || $user->approvedRequests->contains(Auth::user()->id)): ?>
                    <div class="btn-group">
                        <a href="#" class="btn btn-default btn-xs dropdown-toggle" style="border-radius:50px;" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            <i class="fa fa-check-circle" aria-hidden="true"></i> Friends <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo e(route('unFriend',['regno' => $user->reg_no])); ?>">Unfriend</a></li>
                        </ul>
                    </div>
                <?php endif; ?>
            <?php if(Auth::user()->reg_no == $user->reg_no): ?>
                <button type="button" class="btn btn-primary btn-xs" id="updatePhotoBtn" data-toggle="modal" data-target="#myModalAvatar" style="border-radius:50px">Update Photo</button>
            <?php else: ?>
                    <?php if(count($mutualFriends) != 0): ?>
                        <button type="button" class="btn btn-primary btn-xs" data-toggle="modal" data-target="#myModalMutuals" style="border-radius:50px;">
                            <span class="badge"><?php echo e(count($mutualFriends)); ?></span> Mutual
                        </button>
                    <?php endif; ?>
            <?php endif; ?>
                <div>
                    <br>
                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <strong> Success! </strong><?php echo e(session()->get('success')); ?>

                        </div>
                    <?php elseif($errors->has('image')): ?>
                        <div class="alert alert-danger" role="alert">
                            <strong> Error! </strong><?php echo e($errors->first('image')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div id="bg" class="col-md-9">
                <div class="container-fluid">
                    
                    
                    
                                <dl class="dl-horizontal">
                                    <dt>Academic Year:</dt>
                                    <dd><?php echo e($user->usersInfo->academicYear_from); ?> - <?php echo e($user->usersInfo->academicYear_to); ?></dd>
                                </dl>
                                <hr>
                                <dl class="dl-horizontal">
                                    <dt>Institute:</dt>
                                    <dd><?php echo e($user->institutes->name); ?></dd>
                                </dl>
                                <hr>
                                <dl class="dl-horizontal">
                                    <dt>Programme:</dt>
                                    <dd><?php echo e($user->programmes->name); ?></dd>
                                </dl>
                                <hr>
                                <dl class="dl-horizontal">
                                    <dt>High School:</dt>
                                    <dd><?php echo e($user->usersInfo->high_school); ?></dd>
                                </dl>
                                <hr>
                                <dl class="dl-horizontal">
                                    <dt>Current City:</dt>
                                    <dd><?php echo e($user->usersInfo->current_city); ?></dd>
                                    <br>
                                    <dt>Hometown:</dt>
                                    <dd><?php echo e($user->usersInfo->hometown); ?></dd>
                                </dl>
                                <hr>
                                <dl class="dl-horizontal">
                                    <dt>Date of Birth:</dt>
                                    <?php if(Auth::user()->approvedRequests->contains($user->id) || $user->approvedRequests->contains(Auth::user()->id) || Auth::user()->reg_no == $user->reg_no): ?>
                                    <dd><?php echo e($user->usersInfo->born_day); ?> <?php echo e($user->usersInfo->born_month); ?> <?php echo e($user->usersInfo->born_year); ?></dd>
                                    <?php else: ?>
                                    <dd>Only <?php echo e($user->first_name); ?>'s friends can see</dd>
                                    <?php endif; ?>
                                </dl>
                                <hr>
                                <dl class="dl-horizontal">
                                    <dt>Gender:</dt>
                                    <dd><?php echo e($user->gender); ?></dd>
                                </dl>
                                <hr>
                                <dl class="dl-horizontal">
                                    <dt>Relationship Status:</dt>
                                    
                                    <?php if(Auth::user()->approvedRequests->contains($user->id) || $user->approvedRequests->contains(Auth::user()->id) || Auth::user()->reg_no == $user->reg_no): ?>
                                        <dd><?php echo e($user->usersInfo->relationship); ?></dd>
                                    <?php else: ?>
                                        <dd>Only <?php echo e($user->first_name); ?>'s friends can see</dd>
                                    <?php endif; ?>
                                </dl>
                                <hr>
                                <dl class="dl-horizontal">
                                    <dt>Favourite Quotes:</dt>
                                    <dd><?php echo clean($user->usersInfo->quotes) ?></dd>
                                </dl>
                                <hr>
                                <dl class="dl-horizontal">
                                    <dt>Interests:</dt>
                                        <dd>
                                            <?php $__currentLoopData = $user->interests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interest): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                <span class="label label-default"><?php echo e($interest->name); ?></span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                        </dd>
                                </dl>
                                <hr>
                                <dl class="dl-horizontal">
                                    <dt>Achievements:</dt>
                                    <dd><?php echo clean($user->usersInfo->achievements) ?></dd>
                                </dl>
                                <hr>
                                <dl class="dl-horizontal">
                                    <dt>About Me:</dt>
                                    <dd><?php echo clean($user->usersInfo->about) ?></dd>
                                </dl>
                            
                        
                        
                                <hr>
                                <dl class="dl-horizontal">
                                    <dt>I'm also on:</dt>
                                    
                                    <dd>
                                    <?php if(Auth::user()->approvedRequests->contains($user->id) || $user->approvedRequests->contains(Auth::user()->id) || Auth::user()->reg_no == $user->reg_no): ?>
                                        <?php if($user->usersInfo->facebook): ?>
                                            <a id="fb" href="<?php echo e(url('https://fb.com/'.$user->usersInfo->facebook)); ?>" target="_blank"><i class="fa fa-facebook-square fa-3x" aria-hidden="true"></i></a>
                                            <a href="<?php echo e(url('https://m.me/'.$user->usersInfo->facebook)); ?>" target="_blank"><img src="<?php echo e(asset('/img/fbme.png')); ?>" style="width:45px;position:relative;top:-10px" /></a>
                                        <?php endif; ?>
                                        <?php if($user->usersInfo->instagram): ?>
                                            <a id="is" href="<?php echo e(url('https://instagram.com/'.$user->usersInfo->instagram)); ?>" target="_blank"><i class="fa fa-instagram fa-3x" aria-hidden="true"></i></a>
                                        <?php endif; ?>
                                        <?php if($user->usersInfo->googleplus): ?>
                                            <a id="gp" href="<?php echo e(url('https://plus.google.com/'.$user->usersInfo->googleplus)); ?>" target="_blank"><i class="fa fa-google-plus-square fa-3x" aria-hidden="true"></i></a>
                                        <?php endif; ?>
                                        <?php if($user->usersInfo->linkedin): ?>
                                            <a id="li" href="<?php echo e(url('https://in.linkedin.com/in/'.$user->usersInfo->linkedin)); ?>" target="_blank"><i class="fa fa-linkedin-square fa-3x" aria-hidden="true"></i></a>
                                        <?php endif; ?>
                                        <?php if($user->usersInfo->twitter): ?>
                                            <a id="tw" href="<?php echo e(url('https://twitter.com/'.$user->usersInfo->twitter)); ?>" target="_blank"><i class="fa fa-twitter-square fa-3x" aria-hidden="true"></i></a>
                                        <?php endif; ?>
                                        <?php if($user->usersInfo->youtube): ?>
                                            <a id="yt" href="<?php echo e(url('https://youtube.com/'.$user->usersInfo->youtube)); ?>" target="_blank"><i class="fa fa-youtube-square fa-3x" aria-hidden="true"></i></a>
                                        <?php endif; ?>
                                        <?php if($user->usersInfo->skype): ?>
                                            <a id="sk" data-toggle="tooltip" data-placement="bottom" title="<?php echo e($user->usersInfo->skype); ?>"><i class="fa fa-skype fa-3x" aria-hidden="true"></i></a>
                                        <?php endif; ?>
                                        <?php if($user->usersInfo->snapchat): ?>
                                            <a id="sc" data-toggle="tooltip" data-placement="bottom" title="<?php echo e($user->usersInfo->snapchat); ?>"><i class="fa fa-snapchat-square fa-3x" aria-hidden="true"></i></a>
                                        <?php endif; ?>
                                        <?php if($user->usersInfo->telegram): ?>
                                            <a id="te" data-toggle="tooltip" data-placement="bottom" title="<?php echo e($user->usersInfo->telegram); ?>"><i class="fa fa-telegram fa-3x" aria-hidden="true"></i></a>
                                        <?php endif; ?>
                                        <?php if($user->usersInfo->whatsapp): ?>
                                            <a id="wq" data-toggle="tooltip" data-placement="bottom" title="<?php echo e($user->usersInfo->whatsapp); ?>"><i class="fa fa-whatsapp fa-3x" aria-hidden="true"></i></a>
                                        <?php endif; ?>
                                        <?php if($user->usersInfo->github): ?>
                                            <a id="gh" href="<?php echo e(url('https://github.com/'.$user->usersInfo->github)); ?>" target="_blank"><i class="fa fa-github-square fa-3x" aria-hidden="true"></i></a>
                                        <?php endif; ?>
                                        <?php if($user->usersInfo->steam): ?>
                                            <a id="st" href="<?php echo e(url('https://steamcommunity.com/'.$user->usersInfo->steam)); ?>" target="_blank"><i class="fa fa-steam-square fa-3x" aria-hidden="true"></i></a>
                                        <?php endif; ?>
                                    </dd>
                                    <?php else: ?>
                                        <dd>Only <?php echo e($user->first_name); ?>'s friends can see</dd>
                                    <?php endif; ?>
                                </dl>
                            
                    
                        
                            
                        
                    
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" id="myModalAvatar">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form id="avatarUploadForm" role="form" method="post" enctype="multipart/form-data" action="<?php echo e(route('ProfileAvatar')); ?>">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title" id="myModalLabel">Update Photo</h4>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 col-md-offset-3">
                                <div class="thumbnail">
                                    <img src="<?php echo e(asset('/img/loading.gif')); ?>" id="avatarLoading" style="display:none">
                                    
                                    <?php if(!is_null($user->usersInfo->avatar)): ?>
                                        <img src="<?php echo e(asset('/uploads/avatars/'.$user->usersInfo->user_regno.'/'.$user->usersInfo->avatar)); ?>" id="avatar">
                                    <?php elseif($user->gender == 'Male'): ?>
                                        <img src="<?php echo e(asset('/uploads/avatars/default_male.jpg')); ?>" id="avatar">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('/uploads/avatars/default_female.jpg')); ?>" id="avatar">
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 col-md-offset-3">
                            <label>Select Your Image</label><br/>
                            <input type="file" name="image" id="image" accept="image/*" required>
                            <small>(max. file size 7MB)</small>
                            <br>
                            <div id="progress" class="">
                                <div id="progressBar" class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">0%</div>
                            </div>
                        </div>

                        <input type="hidden"  name="x" id="x">
                        <input type="hidden"  name="y" id="y">
                        <input type="hidden"  name="width" id="w">
                        <input type="hidden"  name="height" id="h">
                        <input type="hidden"  name="scale" id="scale">
                        <input type="hidden"  name="angle" id="angle">

                        <div class="row">
                            <div class="col-md-6 col-md-offset-3">
                                <a href='#' id='rotate_left'  title='Rotate left'><i class='fa fa-rotate-left fa-3x'></i></a>
                                <a href='#' id='zoom_out'     title='Zoom out'><i class='fa fa-search-minus fa-3x'></i></a>
                                <a href='#' id='fit'          title='Fit image'><i class='fa fa-arrows-alt fa-3x'></i></a>
                                <a href='#' id='zoom_in'      title='Zoom in'><i class='fa fa-search-plus fa-3x'></i></a>
                                <a href='#' id='rotate_right' title='Rotate right'><i class='fa fa-rotate-right fa-3x'></i></a>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal" style="border-radius:50px">Close</button>
                        <button type="submit" class="btn btn-primary" id="submit" style="border-radius:50px">Save changes</button>
                    </div>
                    <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token">
                </form>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    
    <!-- Modal Mutual Friends -->
    <div class="modal fade" id="myModalMutuals" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">Mutual Friends</h4>
                </div>
                <div class="modal-body">
                    <?php if(count($mutualFriends) > 1): ?>
                        <div class="row" style="display:flex; flex-wrap: wrap;">
                            <?php $__currentLoopData = $mutualFriends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mutualFriend): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <div class="col-md-3 col-xs-6">
                                    <a href="<?php echo e(route('profile',['regno' => $mutualFriend->reg_no])); ?>">

                                        <?php if(!is_null($mutualFriend->usersInfo->avatar)): ?>

                                            <img style="height:100px; width: 100px;" src="<?php echo e(asset('/uploads/avatars/'.$mutualFriend->usersInfo->user_regno.'/'.$mutualFriend->usersInfo->avatar)); ?>">

                                        <?php elseif($mutualFriend->gender == 'Male'): ?>

                                            <img style="height:100px; width: 100px;" src="<?php echo e(asset('/uploads/avatars/default_male.jpg')); ?>">

                                        <?php else: ?>

                                            <img style="height:100px; width: 100px;" src="<?php echo e(asset('/uploads/avatars/default_female.jpg')); ?>">

                                        <?php endif; ?>
                                    </a>
                                    <p><?php echo e($mutualFriend->full_name); ?></p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </div>
                    <?php else: ?>
                        <div class="row">
                            <?php $__currentLoopData = $mutualFriends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mutualFriend): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <div class="col-md-3 col-xs-6">
                                    <a href="<?php echo e(route('profile',['regno' => $mutualFriend->reg_no])); ?>">

                                        <?php if(!is_null($mutualFriend->usersInfo->avatar)): ?>

                                            <img style="height:100px; width: 100px;" src="<?php echo e(asset('/uploads/avatars/'.$mutualFriend->usersInfo->user_regno.'/'.$mutualFriend->usersInfo->avatar)); ?>">

                                        <?php elseif($mutualFriend->gender == 'Male'): ?>

                                            <img style="height:100px; width: 100px;" src="<?php echo e(asset('/uploads/avatars/default_male.jpg')); ?>">

                                        <?php else: ?>

                                            <img style="height:100px; width: 100px;" src="<?php echo e(asset('/uploads/avatars/default_female.jpg')); ?>">

                                        <?php endif; ?>
                                    </a>
                                    <p><?php echo e($mutualFriend->full_name); ?></p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal" style="border-radius:50px;">Close</button>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            /*$('.album').viewer({
                title: false,
                movable: false,
                maxZoomRatio: 10
            });*/

            $('.dp').viewer({
                title: false,
                movable: false,
                maxZoomRatio: 10
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>