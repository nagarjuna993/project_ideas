
    <?php if(Auth::check()): ?>
    <i class="fa fa-bell fa-2x" aria-hidden="true" role="button" data-toggle="modal" data-target=".bs-example-modal-sm" style="margin-top:400px; position:fixed; z-index:1000;">
        <span class="badge" style="margin-left: -30px; margin-bottom: 70px; position:relative;"><?php if($countPendingFriends): ?><?php echo e($countPendingFriends); ?><?php elseif($notification): ?><?php echo e($notification); ?><?php endif; ?></span>
    </i>
    <?php endif; ?>

    <div class="modal fade bs-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <ul class="nav nav-pills nav-stacked text-center">
                    <li><a href="<?php echo e(url('/allfriends')); ?>">All Friends <span class="badge"><?php if($countFriends): ?><?php echo e($countFriends); ?><?php endif; ?></span></a></li>
                    <li><a href="<?php echo e(url('/pendingfriends')); ?>">Requests Pending <span class="badge"><?php if($countPendingFriends): ?><?php echo e($countPendingFriends); ?><?php endif; ?></span></a></li>
                    <li><a href="<?php echo e(url('/requestedfriends')); ?>">Requests Sent <span class="badge"><?php if($countRequestedFriends): ?><?php echo e($countRequestedFriends); ?><?php endif; ?></span></a></li>
                    <li><a href="<?php echo e(url('/notification')); ?>">Notification <span class="badge"><?php if($notification): ?><?php echo e($notification); ?><?php endif; ?></span></a></li>
                    <li><a href="<?php echo e(url('/inbox')); ?>">Inbox <span class="badge"></span></a></li>
                </ul>
            </div>
        </div>
    </div>