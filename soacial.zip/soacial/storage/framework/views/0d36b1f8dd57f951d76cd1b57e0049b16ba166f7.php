<?php $__env->startSection('content'); ?>

    <div id="box" class="col-md-12">
        <div class="container-fluid">
            <div class="jumbotron text-center">
                <h2>Error code 500</h2>
                <p>Internal Server Error</p>
                <a class="btn btn-primary" href="<?php echo e(url('/')); ?>">Try Again</a>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>