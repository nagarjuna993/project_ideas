<?php echo $__env->make('template.notifier', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>




<div class="container text-center">
    <form id="filter" method="get" role="form" action="<?php echo e(route('community')); ?>">
        <input type="hidden" name="alpha" value="<?php echo e(request()->input('alpha')); ?>">
        <input type="hidden" name="institute" value="<?php echo e(request()->input('institute')); ?>">
        <input type="hidden" name="year" value="<?php echo e(request()->input('year')); ?>">
        <input type="hidden" name="interest" value="<?php echo e(request()->input('interest')); ?>">
        <input type="hidden" name="programme" value="<?php echo e(request()->input('programme')); ?>">
        
        
        
        <div class="row" style="display:flex;">
            <div class="col-md-8 col-md-offset-2 col-sm-8 col-sm-offset-2 col-xs-12">
                <input type="text" class="form-control" name="query" id="query" value="<?php echo e(request()->input('query')); ?>"
                    placeholder="Search Anyone :)" autocomplete="off" style="border-radius:50px" required>
            </div>
            <button type="submit" class="fa fa-search fa-2x" aria-hidden="true" style="position:relative; margin-left: -70px; background-color: transparent; border-color: transparent"></button>
        </div>

        <div class="panel panel-default" style="border-radius: 50px;">
            <div class="panel-heading" role="tab" id="headingOne" style="border-radius: 50px;">
                <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true"
                    aria-controls="collapseOne">
                    <h4 class="panel-title">
                        Filter
                    </h4>
                </a>
            </div>
            <div id="collapseOne" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne">
                <div class="panel-body">
                    <ul class="nav nav-tabs nav-justified">
                        <li role="presentation" class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true"
                                aria-expanded="false">
                                Alphabet <span class="caret"></span> <span class="label label-default"><?php echo e(request()->input('alpha')); ?></span>
                            </a>
                            <ul class="dropdown-menu alphabet" style="height:auto; max-height:150px; overflow-x:hidden;">
                                <li value=""><a href="#">---Reset---</a></li>
                                <li value="A"><a href="#">A</a></li>
                                <li value="B"><a href="#">B</a></li>
                                <li value="C"><a href="#">C</a></li>
                                <li value="D"><a href="#">D</a></li>
                                <li value="E"><a href="#">E</a></li>
                                <li value="F"><a href="#">F</a></li>
                                <li value="G"><a href="#">G</a></li>
                                <li value="H"><a href="#">H</a></li>
                                <li value="I"><a href="#">I</a></li>
                                <li value="J"><a href="#">J</a></li>
                                <li value="K"><a href="#">K</a></li>
                                <li value="L"><a href="#">L</a></li>
                                <li value="M"><a href="#">M</a></li>
                                <li value="N"><a href="#">N</a></li>
                                <li value="O"><a href="#">O</a></li>
                                <li value="P"><a href="#">P</a></li>
                                <li value="Q"><a href="#">Q</a></li>
                                <li value="R"><a href="#">R</a></li>
                                <li value="S"><a href="#">S</a></li>
                                <li value="T"><a href="#">T</a></li>
                                <li value="U"><a href="#">U</a></li>
                                <li value="V"><a href="#">V</a></li>
                                <li value="W"><a href="#">W</a></li>
                                <li value="X"><a href="#">X</a></li>
                                <li value="Y"><a href="#">Y</a></li>
                                <li value="Z"><a href="#">Z</a></li>
                            </ul>
                        </li>
                        <li role="presentation" class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true"
                                aria-expanded="false">
                                Institute <span class="caret"></span> <span class="label label-default"><?php echo e(request()->input('institute')); ?></span>
                            </a>
                            <ul class="dropdown-menu institute" style="height:auto; max-height:150px; overflow-x:hidden;">
                                <li value=""><a href="#">---Reset---</a></li>
                                <?php $__currentLoopData = $institutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $institute): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <li value="<?php echo e($institute->id); ?>"><a href="#"><?php echo e($institute->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </ul>
                        </li>
                        <li role="presentation" class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true"
                                aria-expanded="false">
                                Programme <span class="caret"></span> <span class="label label-default"><?php echo e(request()->input('programme')); ?></span>
                            </a>
                            <ul class="dropdown-menu programme" style="height:auto; max-height:150px; overflow-x:hidden;">
                                <li value=""><a href="#">---Reset---</a></li>
                                <?php $__currentLoopData = $programmes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programme): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <li value="<?php echo e($programme->id); ?>"><a href="#"><?php echo e($programme->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </ul>
                        </li>
                        <li role="presentation" class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true"
                                aria-expanded="false">
                                Passout Year <span class="caret"></span> <span class="label label-default"><?php echo e(request()->input('year')); ?></span>
                            </a>
                            <ul class="dropdown-menu year" style="height:auto; max-height:150px; overflow-x:hidden;">
                                <li value=""><a href="#">---Reset---</a></li>
                                <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <li value="<?php echo e($year->academicYear_to); ?>"><a href="#"><?php echo e($year->academicYear_to); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </ul>
                        </li>
                        <li role="presentation" class="dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true"
                                aria-expanded="false">
                                Interest <span class="caret"></span> <span class="label label-default"><?php echo e(request()->input('interest')); ?></span>
                            </a>
                            <ul class="dropdown-menu interest" style="height:auto; max-height:150px; overflow-x:hidden;">
                                <li value=""><a href="#">---Reset---</a></li>
                                <?php $__currentLoopData = $interests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $interest): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <li value="<?php echo e($interest->id); ?>"><a href="#"><?php echo e($interest->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </ul>
                        </li>
                        

                        
                        <li>
                            <a href="<?php echo e(url('/')); ?>">
                                <small>Reset all</small>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </form>
</div>

<script>
    $(document).ready(function() {

            var form = $('#filter');

            $('.alphabet li').click(function () {
                var alpha = $(this).attr("value");
                form.find('input[name="alpha"]').val(alpha);
                form.submit();
            });
            $('.institute li').click(function () {
                var institute = $(this).attr("value");
                form.find('input[name="institute"]').val(institute);
                form.submit();
            });
            if(!$('input[name="institute"]').val()) {
                $('.programme li').append('<li>You have not selected any Institute</li>').css('margin-left','15px');
            }
            else{
                $('.programme li').click(function () {
                    var programme = $(this).attr("value");
                    form.find('input[name="programme"]').val(programme);
                    form.submit();
                });
            }
            $('.year li').click(function () {
                var year = $(this).attr("value");
                form.find('input[name="year"]').val(year);
                form.submit();
            });
            $('.interest li').click(function () {
                var interest = $(this).attr("value");
                form.find('input[name="interest"]').val(interest);
                form.submit();
            });

            var path = "<?php echo e(route('searchProfile')); ?>";
            $('#query').typeahead({
                ajax: path,
                items: 20,
                valueField: 'id',
                displayField: 'full_name',
                scrollBar: true,
                autoSelect: false,
                alignWidth: true,
                onSelect: function () {
                    $('#query').change(function() {
                        form.submit();
                    });
                }
            });

            form.submit(function() {
                $(this).find(":input").filter(function(){ return !this.value; }).attr("disabled", "disabled");
                return true; // ensure form still submits
            });
            /*$('.gender li').click(function () {
                var gender = $(this).attr("value");
                form.find('input[name="gender"]').val(gender);
                form.submit();
            });*/

        });
    </script>

<div class="container">
    <?php if(!$users->count()): ?>
    <div class="alert alert-danger" role="alert">
        <p>No Results</p>
    </div>
    <?php else: ?>
    <div class="row" style="display:flex; flex-wrap: wrap;">
        
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <div class="col-md-3 col-sm-4">
            <div class="thumbnail">
                <?php if(!is_null($user->usersInfo->avatar)): ?>
                <a href="<?php echo e(route('profile',['regno' => $user->reg_no])); ?>">
                    <img src="<?php echo e(asset('/uploads/avatars/'.$user->usersInfo->user_regno.'/'.$user->usersInfo->avatar)); ?>" />
                </a>
                <?php elseif($user->gender == 'Male'): ?>
                <a href="<?php echo e(route('profile',['regno' => $user->reg_no])); ?>">
                    <img src="<?php echo e(asset('/uploads/avatars/default_male.jpg')); ?>" />
                </a>
                <?php else: ?>
                <a href="<?php echo e(route('profile',['regno' => $user->reg_no])); ?>">
                    <img src="<?php echo e(asset('/uploads/avatars/default_female.jpg')); ?>" />
                </a>
                <?php endif; ?>

                <?php if($user->reg_no == 1441012011): ?>
                <div class="label label-info" style="display:block;"></div>
                <?php endif; ?>

                <div class="caption text-center">
                    <strong style="font-size: 20px"><?php echo e($user->full_name); ?></strong>
                    <h6><?php echo e($user->usersInfo->academicYear_from); ?> - <?php echo e($user->usersInfo->academicYear_to); ?></h6>
                    <h6><?php echo e($user->institutes->name); ?></h6>

                    

                    <a href="<?php echo e(route('profile',['regno' => $user->reg_no])); ?>" class="btn btn-primary btn-xs" role="button"
                        style="border-radius:50px"><i class="fa fa-user-circle" aria-hidden="true"></i> Profile</a>

                    <?php if(!Auth::user()->pendingRequests->contains($user->id) &&
                    !$user->pendingRequests->contains(Auth::user()->id) &&
                    !$user->approvedRequests->contains(Auth::user()->id) &&
                    !Auth::user()->approvedRequests->contains($user->id)): ?>

                    <a href="<?php echo e(route('addFriend',['regno' => $user->reg_no])); ?>" class="btn btn-default btn-xs friendBtn"
                        role="button" style="border-radius:50px"><i class="fa fa-user-plus" aria-hidden="true"></i> Add
                        Friend</a>

                    <?php endif; ?>

                    <?php if(Auth::user()->pendingRequests->contains($user->id) &&
                    !$user->pendingRequests->contains(Auth::user()->id)): ?>

                    <a href="#" class="btn btn-default btn-xs disabled" role="button" style="border-radius:50px; cursor:default;">
                        <i class="fa fa-thumbs-up" aria-hidden="true"></i> Request Sent
                    </a>

                    
                    <?php endif; ?>

                    <?php if(!Auth::user()->pendingRequests->contains($user->id) &&
                    $user->pendingRequests->contains(Auth::user()->id)): ?>

                    <div class="btn-group">
                        <a href="#" class="btn btn-default btn-xs dropdown-toggle" style="border-radius:50px;"
                            data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            <i class="fa fa-clock-o" aria-hidden="true"></i>
                            Request Pending <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu pendingRequestBtn">
                            <li><a href="<?php echo e(route('pendingRequest',['regno' => $user->reg_no, 'accept' => true])); ?>">Accept</a></li>
                            <li><a href="<?php echo e(route('pendingRequest',['regno' => $user->reg_no, 'accept' => false])); ?>">Reject</a></li>
                        </ul>
                    </div>
                    <?php endif; ?>
                    <?php if(Auth::user()->approvedRequests->contains($user->id) ||
                    $user->approvedRequests->contains(Auth::user()->id)): ?>

                    

                    <div class="btn-group">
                        <a href="#" class="btn btn-default btn-xs dropdown-toggle" style="border-radius:50px;"
                            data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            <i class="fa fa-check-circle" aria-hidden="true"></i> Friends <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo e(route('unFriend',['regno' => $user->reg_no])); ?>">Unfriend</a></li>
                        </ul>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        
    </div>
    <?php endif; ?>
</div>
<div class="container text-center">
    <?php echo e($users->appends(request()->input())->links()); ?>

</div>

<!-- Modal Mutual Friends -->




<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>