<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="google-site-verification" content="D9atvgdrQNeVyTf4UhOjwtJX01p6WjhrvAp5VlUgq3Q" />
    <meta name="description" content="SOAcial, a social community website for the students of Siksha 'O' Anusandhan (Deemed to be University), Bhubaneswar. Here you can search the alumnus or fresher of any institute of any programme of any year and of any interests.">
    <meta name="keywords" content="soacial, soacial.in, siksha o anusandhan, soa bhubaneswar, soacial bhubaneswar">


    <title>SOAcial</title>

    <link rel="icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootswatch/3.3.7/flatly/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/imageviewer/0.5.1/viewer.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('/css/jquery.guillotine.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/css/notify.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('/css/styles.css')); ?>">
    
    
    
    
    
    
    

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('/js/bootstrap-typeahead.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/jquery.guillotine.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/js/notify.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/imageviewer/0.5.1/viewer.min.js"></script>
    <script src="<?php echo e(asset('/js/custom.js')); ?>"></script>
    
    
    
    
    
    
    

    <script type="application/ld+json">
        {
            "@context": "http://schema.org",
            "@type": "Organization",
            "url": "http://www.soacial.in",
            "logo": "http://www.soacial.in/logo.png"
        }
    </script>
    <script>
        $(document).ready(function() {

            $(".loading").fadeOut();

            if (!navigator.cookieEnabled)
            {
                $('#warningModal').addClass('show');
            }

            $('[data-toggle=tooltip]').tooltip();
        });
    </script>

    <div class="modal" tabindex="-1" role="dialog" id="warningModal" aria-labelledby="mySmallModalLabel">
        <div class="modal-dialog modal-sm" role="document">
            <div class="alert alert-danger">
                <p>Seems like <strong>Cookies</strong> are disabled in this browser. Without <strong>Cookies</strong>, this website will not work.</p>
            </div>
        </div>
    </div>

    <noscript style="width:100%; height:100%; z-index:100000; position:absolute;">
        <div class="modal show" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel">
            <div class="modal-dialog modal-sm" role="document">
                <div class="alert alert-danger">
                    <p>Seems like <strong>Javascript</strong> is disabled in this browser. Without <strong>Javascript</strong>, this website will not work.</p>
                </div>
            </div>
        </div>
    </noscript>

    <?php
    header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
    header("Cache-Control: post-check=0, pre-check=0", false);
    header("Pragma: no-cache");
    header('Content-Type: text/html');?>
</head>
<body style="padding-top: 70px;">
<div class="loading"></div>



<?php echo $__env->make('template.navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>


</body>
<footer class="footer">
    <div class="container text-center">
        <ul class="list-inline">
            <li role="button" data-toggle="modal" data-target="#about"><a href=""></a>About</li>
            <li role="button" data-toggle="modal" data-target="#contactUs"><a href=""></a>Contact</li>
            <li role="button" data-toggle="modal" data-target="#terms"><a href=""></a>Terms</li>
            <li role="button" data-toggle="modal" data-target="#privacy"><a href=""></a>Privacy</li>
        </ul>
        <ul class="list-inline">
            <li>SOAcial &copy; 2017</li>
        </ul>
    </div>

    <!-- About Us -->
    <div class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" id="about">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">About Us</h4>
                </div>
                <div class="modal-body">
                    <strong>SOAcial</strong>, a social network platform for the students of SOA University, Bhubaneswar.
                    Here you can search anyone from any institute of any programme of any year and of any interests.
                    <br>
                    Siksha 'O' Anusandhan University has 9 institutes namely:
                    <ol>
                        <li>Institute of Technical Education and Research (ITER)</li>
                        <li>School of Hotel Management (SHM)</li>
                        <li>Institute of Business & Computer Studies (IBCS)</li>
                        <li>Sum Nursing College (SNC)</li>
                        <li>SOA National Institute of Law (SNIL)</li>
                        <li>School of Pharmaceutical Sciences (SPS)</li>
                        <li>Institute of Dental Sciences (IDS)</li>
                        <li>Institute of Medical Sciences & SUM Hospital (IMS & SUM)</li>
                        <li>Institute of Agriculture Sciences (IAS)</li>
                    </ol>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal" style="border-radius: 50px;">Close</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Contact Us -->
    <div class="modal fade" tabindex="-1" role="dialog" id="contactUs">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Contact Us</h4>
                </div>
                <div class="modal-body">
                    <strong>For any queries, Contact here:</strong>
                    <ul>
                        <li>admin@soacial.in</li>
                    </ul>

                    
                </div>
                <div class="modal-footer">
                    
                    <button type="button" class="btn btn-default" data-dismiss="modal" style="border-radius: 50px;">Close</button>
                </div>
                
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->

    <!-- Terms and Conditions -->
    <div class="modal fade" tabindex="-1" role="dialog" id="terms">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Terms and Conditions</h4>
                </div>
                <div class="modal-body">
                    <strong>We hold the right to terminate your account if found violating the terms below</strong>
                    <ul>
                        <li>Do not create account if you are not from any institute of SOA University.</li>
                        <li>Do not provide any false personal information while creating an account for yourself.</li>
                        <li>Do not create more than one personal account.</li>
                        <li>Do not misuse any information about any person you read.</li>
                        <li>Do not put pornographic photo as your profile picture.</li>
                        <li>Do not put abusive words in your personal information.</li>
                        <li>If you want to change or update your information that are unchangeable, kindly contact us.</li>
                    </ul>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal" style="border-radius: 50px;">Close</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->

    <!-- Privacy Policy -->
    <div class="modal fade" tabindex="-1" role="dialog" id="privacy">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">Privacy Policy</h4>
                </div>
                <div class="modal-body">
                    <ul>
                        <li>Do not create password which is same in your other social accounts.</li>
                        <li>Do not accept/send friend request if you feel suspicious or doubtful.</li>
                        <li>Your personal information won't be shared or viewed unless you or the other person accepts the friend request.</li>
                        <li>For Register and Login, use your personal devices only.</li>
                    </ul>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal" style="border-radius: 50px;">Close</button>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
</footer>
</html>