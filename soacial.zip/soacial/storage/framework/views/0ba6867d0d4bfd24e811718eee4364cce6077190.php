<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <img src="<?php echo e(asset('img/logo2.png')); ?>" alt="Brand" style="margin-top: -15px; max-width: 50px;">
            </a>
            <button class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navcol-1"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
        </div>
        <div class="collapse navbar-collapse" id="navcol-1">
            <?php if(Auth::check()): ?>
            <ul class="nav navbar-nav">
                <li role="button"> <a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li role="button"> <a href="<?php echo e(url('/community')); ?>">Community</a></li>
                
            </ul>
            <?php endif; ?>
            <ul class="nav navbar-nav navbar-right">
                <?php if(Auth::check()): ?>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><?php echo e(Auth::user()->first_name); ?> <span class="caret"></span></a>
                    <ul class="dropdown-menu">
                        <li><a href="<?php echo e(route('profile',['regno' => Auth::user()->reg_no])); ?>">My Profile</a></li>
                        <li><a href="<?php echo e(route('editProfile')); ?>">Edit Profile</a></li>
                        <li><a href="<?php echo e(route('changePassword')); ?>">Change Password</a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="<?php echo e(route('logout_user')); ?>">Logout</a></li>
                        <li role="separator" class="divider"></li>
                        <li><a href="<?php echo e(route('deactivateAccount',['regno' => Auth::user()->reg_no])); ?>">Deactivate Account</a></li>
                    </ul>
                </li>
                <?php else: ?>
                    <li role="button" ><a data-toggle="modal" data-target="#myModallogin">Login</a></li>
                    <li role="button" ><a data-toggle="modal" data-target="#myModalregister">Register</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>