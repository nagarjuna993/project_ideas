<?php echo $__env->make('template.notifier', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div>
            <!-- Nav tabs -->
            <ul class="nav nav-tabs" role="tablist">
                <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Friends <span class="badge"></span></a></li>
                <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Others <span class="badge"></span></a></li>
            </ul>
            <br>
            <!-- Tab panes -->
            <div class="tab-content">
                <div role="tabpanel" class="tab-pane fade in active" id="home">
                    <div class="col-md-6">
                        <ul class="list-group">
                            <?php if($inboxFriends->count()): ?>
                                <?php $__currentLoopData = $inboxFriends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inboxFriend): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <?php if(Auth::user()->approvedRequests->contains($inboxFriend->id) || $inboxFriend->approvedRequests->contains(Auth::user()->id)): ?>
                                        <?php if($inboxFriend->seen == 0): ?>
                                            <li class="list-group-item" style="background-color: lightblue;">
                                        <?php else: ?>
                                            <li class="list-group-item">
                                        <?php endif; ?>
                                            <div class="media">
                                                <div class="media-left media-top">
                                                    <?php if(!is_null($inboxFriend->usersInfo->avatar)): ?>
                                                        <a href="<?php echo e(route('chat',['regno' => $inboxFriend->reg_no])); ?>">
                                                            <img style="min-height:40px; min-width:40px;" class="media-object" src="<?php echo e(asset('/uploads/avatars/'.$inboxFriend->reg_no.'/'.$inboxFriend->usersInfo->avatar)); ?>"/>
                                                        </a>
                                                    <?php elseif($inboxFriend->gender == 'Male'): ?>
                                                        <a href="<?php echo e(route('chat',['regno' => $inboxFriend->reg_no])); ?>">
                                                            <img style="min-height:40px; min-width:40px;" class="media-object" src="<?php echo e(asset('/uploads/avatars/default_male.jpg')); ?>"/>
                                                        </a>
                                                    <?php else: ?>
                                                        <a href="<?php echo e(route('chat',['regno' => $inboxFriend->reg_no])); ?>">
                                                            <img style="min-height:40px; min-width:40px;" class="media-object" src="<?php echo e(asset('/uploads/avatars/default_female.jpg')); ?>"/>
                                                        </a>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="media-body">
                                                    <span class="fa fa-cog dropdown-toggle pull-right" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></span>
                                                    <ul class="dropdown-menu pull-right">
                                                        <li><a href="#">Delete</a></li>
                                                        <li><a href="#">Report</a></li>
                                                        <li><a href="#">Block</a></li>
                                                    </ul>
                                                    <a href="<?php echo e(route('chat',['regno' => $inboxFriend->reg_no])); ?>" style="color:inherit;">
                                                        <strong class="media-heading"><?php echo e($inboxFriend->full_name); ?></strong>
                                                        <div class="label label-info"><?php echo e($inboxFriend->institutes->name); ?></div>
                                                    </a>
                                                    <br>
                                                   
                                                </div>
                                            </div>
                                        </li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
                <div role="tabpanel" class="tab-pane fade" id="profile">
                    <div class="col-md-6">
                        <ul class="list-group">
                            <?php if($inboxFriends->count()): ?>
                                <?php $__currentLoopData = $inboxFriends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inboxFriend): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <?php if(!Auth::user()->approvedRequests->contains($inboxFriend->id) && !$inboxFriend->approvedRequests->contains(Auth::user()->id)): ?>
                                        <?php if($inboxFriend->seen == 0): ?>
                                            <li class="list-group-item" style="background-color: lightblue;">
                                        <?php else: ?>
                                            <li class="list-group-item">
                                        <?php endif; ?>
                                            <div class="media">
                                                <div class="media-left media-top">
                                                    <?php if(!is_null($inboxFriend->usersInfo->avatar)): ?>
                                                        <a href="<?php echo e(route('chat',['regno' => $inboxFriend->reg_no])); ?>">
                                                            <img style="min-height:40px; min-width:40px;" class="media-object" src="<?php echo e(asset('/uploads/avatars/'.$inboxFriend->reg_no.'/'.$inboxFriend->usersInfo->avatar)); ?>"/>
                                                        </a>
                                                    <?php elseif($inboxFriend->gender == 'Male'): ?>
                                                        <a href="<?php echo e(route('chat',['regno' => $inboxFriend->reg_no])); ?>">
                                                            <img style="min-height:40px; min-width:40px;" class="media-object" src="<?php echo e(asset('/uploads/avatars/default_male.jpg')); ?>"/>
                                                        </a>
                                                    <?php else: ?>
                                                        <a href="<?php echo e(route('chat',['regno' => $inboxFriend->reg_no])); ?>">
                                                            <img style="min-height:40px; min-width:40px;" class="media-object" src="<?php echo e(asset('/uploads/avatars/default_female.jpg')); ?>"/>
                                                        </a>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="media-body">
                                                    <span class="fa fa-cog dropdown-toggle pull-right" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></span>
                                                    <ul class="dropdown-menu pull-right">
                                                        <li><a href="#">Delete</a></li>
                                                        <li><a href="#">Report</a></li>
                                                        <li><a href="#">Block</a></li>
                                                    </ul>
                                                    <a href="<?php echo e(route('chat',['regno' => $inboxFriend->reg_no])); ?>" style="color:inherit;">
                                                        <strong class="media-heading"><?php echo e($inboxFriend->full_name); ?></strong>
                                                        <div class="label label-info"><?php echo e($inboxFriend->institutes->name); ?></div>
                                                    </a>
                                                    <br>
                                                    
                                                </div>
                                            </div>
                                        </li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container text-center">
        
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>