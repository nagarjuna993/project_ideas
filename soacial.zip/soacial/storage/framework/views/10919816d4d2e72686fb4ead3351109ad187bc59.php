<?php echo $__env->make('template.notifier', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="col-md-6">
            <?php if($users->count()): ?>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <div class="thumbnail">
                        <div class="media">
                            <div class="media-left">
                                <?php if(!is_null($user->usersInfo->avatar)): ?>
                                    <a href="<?php echo e(route('profile',['regno' => $user->reg_no])); ?>">
                                        <img style="min-height:30px; min-width:30px;" class="media-object" src="<?php echo e(asset('/uploads/avatars/'.$user->usersInfo->user_regno.'/'.$user->usersInfo->avatar)); ?>"/>
                                    </a>
                                <?php elseif($user->gender == 'Male'): ?>
                                    <a href="<?php echo e(route('profile',['regno' => $user->reg_no])); ?>">
                                        <img style="min-height:30px; min-width:30px;" class="media-object" src="<?php echo e(asset('/uploads/avatars/default_male.jpg')); ?>"/>
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e(route('profile',['regno' => $user->reg_no])); ?>">
                                        <img style="min-height:30px; min-width:30px;" class="media-object" src="<?php echo e(asset('/uploads/avatars/default_female.jpg')); ?>"/>
                                    </a>
                                <?php endif; ?>
                            </div>
                            <div class="media-body">
                                <h4 class="media-heading"></h4>
                                <strong><a href="<?php echo e(route('profile',['regno' => $user->reg_no])); ?>"><?php echo e($user->full_name); ?></a></strong> accepted your friend request.
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="container text-center">
        <?php echo e($users->links()); ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>