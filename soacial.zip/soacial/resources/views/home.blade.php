@extends('template.layout')
@include('template.notifier')
@section('content')

    {{--news feed start--}}
    <div class="container">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div>
                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs" role="tablist">
                            <li role="presentation" class="active"><a href="#post" aria-controls="home" role="tab" data-toggle="tab">Create Post</a></li>
                            <li role="presentation"><a href="#event" aria-controls="profile" role="tab" data-toggle="tab">Create Event</a></li>
                        </ul>
                        <!-- Tab panes -->
                        <div class="tab-content" style="padding-top: 10px;">
                            <div role="tabpanel" class="tab-pane fade in active" id="post">
                                <form action="#">
                                    <div class="form-group">
                                        <textarea class="form-control" name="post" rows="2" title="write post" placeholder="Write your post.."></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputpostImg">Upload Image</label>
                                        <input type="file" name="postImg" id="exampleInputpostImg">
                                    </div>
                                    <div class="btn-group pull-right">
                                        <button type="button" class="btn btn-default btn-sm dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"  style="border-radius: 50px;">
                                            Privacy <span class="caret"></span>
                                        </button>
                                        <ul class="dropdown-menu">
                                            <li><a href="#">Friends</a></li>
                                            <li><a href="#">Friends of Friends</a></li>
                                            <li><a href="#">Only me</a></li>
                                        </ul>
                                        <button type="button" class="btn btn-primary btn-sm pull-right" style="border-radius: 50px;">Post</button>
                                    </div>
                                </form>
                            </div>
                            <div role="tabpanel" class="tab-pane fade" id="event">
                                <form action="#">
                                    <div class="form-group">
                                        <label for="exampleInputTitle">Event Title</label>
                                        <input type="text" class="form-control input-sm" id="exampleInputTitle">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputDate">Date</label>
                                        <input type="date" class="form-control input-sm" id="exampleInputDate">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputLocation">Location</label>
                                        <input type="text" class="form-control input-sm" id="exampleInputLocation">
                                    </div>
                                    <div class="form-group">
                                        <label for="exampleInputeventImg">Upload Image</label>
                                        <input type="file" name="eventImg" id="exampleInputeventImg">
                                    </div>
                                    <button type="submit" class="btn btn-primary btn-sm pull-right" style="border-radius: 50px;">Create</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="media">
                        <div class="media-left">
                            <a href="#">
                                <img class="media-object" style="min-width: 50px;" src="{{ asset('/uploads/avatars/default_male.jpg') }}" alt="male_img">
                            </a>
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading">
                                <a href="{{ route('profile',['regno' => '1441012011']) }}" style="color: black">Rohan Tarai</a>
                                <i class="fa fa-cog pull-right" aria-hidden="true"></i>
                            </h4>
                            <small>1 hr ago</small>
                        </div>
                    </div>
                    <br>
                    <div class="embed-responsive embed-responsive-16by9">
                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/6ZfuNTqbHE8"></iframe>
                    </div>
                    <br>
                    <div class="caption">
                        <p>Caption</p>
                    </div>
                    <div class="row text-center">
                        <a href="#" class="col-md-4" style="color: black">Like</a>
                        <a href="#" class="col-md-4" style="color: black">Comment</a>
                        <a href="#" class="col-md-4" style="color: black">Share</a>
                    </div>
                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="media">
                        <div class="media-left">
                            <a href="#">
                                <img class="media-object" style="min-width: 50px;" src="{{ asset('/uploads/avatars/default_male.jpg') }}" alt="male_img">
                            </a>
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading">
                                <a href="{{ route('profile',['regno' => '1441012011']) }}" style="color: black">Rohan Tarai</a>
                                <i class="fa fa-cog pull-right" aria-hidden="true"></i>
                            </h4>
                            <small>1 hr ago</small>
                        </div>
                    </div>
                    <br>
                    <div class="embed-responsive embed-responsive-16by9">
                        <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/6ZfuNTqbHE8"></iframe>
                    </div>
                    <hr>
                    <div class="row text-center">
                        <a href="#" class="col-md-4" style="color: black">Like</a>
                        <a href="#" class="col-md-4" style="color: black">Comment</a>
                        <a href="#" class="col-md-4" style="color: black">Share</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    {{--news feed end--}}


@endsection