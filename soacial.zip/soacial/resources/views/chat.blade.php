@extends('template.layout')
@include('template.notifier')
@section('content')

    <div class="container">
        <div class="panel panel-default">
            <div class="panel-body" style="height:auto; max-height:300px; overflow-x:hidden;">
                <div class="container">
                    <div class="row">

                    </div>
                </div>
            </div>
            <div class="panel-footer">
                <form id="messageForm" role="form" method="post" action="{{ route('chat',['regno' => $chatUser->reg_no]) }}">
                    <input name="_method" type="hidden" value="PUT">
                    <div class="row">
                        <div class="col-md-6 col-sm-6">
                            <input type="text" class="form-control" name="chat" id="chat" placeholder="Type Something :)" autocomplete="off" required>
                        </div>
                        <div class="col-sm-6">
                            <button type="submit" id="chatSendBtn" class="btn btn-default" style="border-radius:50px;">Send</button>
                            <img src="{{ asset('/img/ajax-loader.gif') }}" id="message-loading-indicator" style="display:none;">
                        </div>
                    </div>
                    <input type="hidden" value="{{ csrf_token() }}" name="_token">
                </form>
            </div>
        </div>
    </div>

@endsection