@extends('template.layout')
@include('template.notifier')
@section('content')

    <div class="container">
        <div>
            <!-- Nav tabs -->
            <ul class="nav nav-tabs" role="tablist">
                <li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Friends <span class="badge"></span></a></li>
                <li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Others <span class="badge"></span></a></li>
            </ul>
            <br>
            <!-- Tab panes -->
            <div class="tab-content">
                <div role="tabpanel" class="tab-pane fade in active" id="home">
                    <div class="col-md-6">
                        <ul class="list-group">
                            @if($inboxFriends->count())
                                @foreach($inboxFriends as $inboxFriend)
                                    @if(Auth::user()->approvedRequests->contains($inboxFriend->id) || $inboxFriend->approvedRequests->contains(Auth::user()->id))
                                        @if($inboxFriend->seen == 0)
                                            <li class="list-group-item" style="background-color: lightblue;">
                                        @else
                                            <li class="list-group-item">
                                        @endif
                                            <div class="media">
                                                <div class="media-left media-top">
                                                    @if(!is_null($inboxFriend->usersInfo->avatar))
                                                        <a href="{{ route('chat',['regno' => $inboxFriend->reg_no]) }}">
                                                            <img style="min-height:40px; min-width:40px;" class="media-object" src="{{ asset('/uploads/avatars/'.$inboxFriend->reg_no.'/'.$inboxFriend->usersInfo->avatar) }}"/>
                                                        </a>
                                                    @elseif($inboxFriend->gender == 'Male')
                                                        <a href="{{ route('chat',['regno' => $inboxFriend->reg_no]) }}">
                                                            <img style="min-height:40px; min-width:40px;" class="media-object" src="{{ asset('/uploads/avatars/default_male.jpg') }}"/>
                                                        </a>
                                                    @else
                                                        <a href="{{ route('chat',['regno' => $inboxFriend->reg_no]) }}">
                                                            <img style="min-height:40px; min-width:40px;" class="media-object" src="{{ asset('/uploads/avatars/default_female.jpg') }}"/>
                                                        </a>
                                                    @endif
                                                </div>
                                                <div class="media-body">
                                                    <span class="fa fa-cog dropdown-toggle pull-right" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></span>
                                                    <ul class="dropdown-menu pull-right">
                                                        <li><a href="#">Delete</a></li>
                                                        <li><a href="#">Report</a></li>
                                                        <li><a href="#">Block</a></li>
                                                    </ul>
                                                    <a href="{{ route('chat',['regno' => $inboxFriend->reg_no]) }}" style="color:inherit;">
                                                        <strong class="media-heading">{{ $inboxFriend->full_name }}</strong>
                                                        <div class="label label-info">{{ $inboxFriend->institutes->name }}</div>
                                                    </a>
                                                    <br>
                                                   {{-- <span class="label label-default">{{ $inboxUsersChatsCount }}</span>--}}
                                                </div>
                                            </div>
                                        </li>
                                    @endif
                                @endforeach
                            @endif
                        </ul>
                    </div>
                </div>
                <div role="tabpanel" class="tab-pane fade" id="profile">
                    <div class="col-md-6">
                        <ul class="list-group">
                            @if($inboxFriends->count())
                                @foreach($inboxFriends as $inboxFriend)
                                    @if(!Auth::user()->approvedRequests->contains($inboxFriend->id) && !$inboxFriend->approvedRequests->contains(Auth::user()->id))
                                        @if($inboxFriend->seen == 0)
                                            <li class="list-group-item" style="background-color: lightblue;">
                                        @else
                                            <li class="list-group-item">
                                        @endif
                                            <div class="media">
                                                <div class="media-left media-top">
                                                    @if(!is_null($inboxFriend->usersInfo->avatar))
                                                        <a href="{{ route('chat',['regno' => $inboxFriend->reg_no]) }}">
                                                            <img style="min-height:40px; min-width:40px;" class="media-object" src="{{ asset('/uploads/avatars/'.$inboxFriend->reg_no.'/'.$inboxFriend->usersInfo->avatar) }}"/>
                                                        </a>
                                                    @elseif($inboxFriend->gender == 'Male')
                                                        <a href="{{ route('chat',['regno' => $inboxFriend->reg_no]) }}">
                                                            <img style="min-height:40px; min-width:40px;" class="media-object" src="{{ asset('/uploads/avatars/default_male.jpg') }}"/>
                                                        </a>
                                                    @else
                                                        <a href="{{ route('chat',['regno' => $inboxFriend->reg_no]) }}">
                                                            <img style="min-height:40px; min-width:40px;" class="media-object" src="{{ asset('/uploads/avatars/default_female.jpg') }}"/>
                                                        </a>
                                                    @endif
                                                </div>
                                                <div class="media-body">
                                                    <span class="fa fa-cog dropdown-toggle pull-right" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"></span>
                                                    <ul class="dropdown-menu pull-right">
                                                        <li><a href="#">Delete</a></li>
                                                        <li><a href="#">Report</a></li>
                                                        <li><a href="#">Block</a></li>
                                                    </ul>
                                                    <a href="{{ route('chat',['regno' => $inboxFriend->reg_no]) }}" style="color:inherit;">
                                                        <strong class="media-heading">{{ $inboxFriend->full_name }}</strong>
                                                        <div class="label label-info">{{ $inboxFriend->institutes->name }}</div>
                                                    </a>
                                                    <br>
                                                    {{-- <span class="label label-default">{{ $inboxUsersChatsCount }}</span>--}}
                                                </div>
                                            </div>
                                        </li>
                                    @endif
                                @endforeach
                            @endif
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container text-center">
        {{--{{ $inboxUsers->links() }}--}}
    </div>

@endsection