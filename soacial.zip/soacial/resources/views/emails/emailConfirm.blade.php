<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SOACIAL Account Activation</title>
</head>
<body>
        <h1> Thank You for Registering! </h1>
        <p> Please <a href="{{ url('confirm/'. $token )}}"> Activate your account</a></p>
</body>
</html>