<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title></title>
</head>
<body>
    <h3>Subject: {{ $subject }}</h3>
    <h3>Fullname: {{ $fullname }}</h3>
    <h3>Email Id: {{ $email }}</h3>
    <h3>IP: {{ $ip }}</h3>
    <p>Message: {{ $messages }} </p>
</body>
</html>