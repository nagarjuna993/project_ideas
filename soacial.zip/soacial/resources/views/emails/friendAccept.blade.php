<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SOAcial</title>
</head>
<body>
<p> <strong>{{ $fullname }}</strong> has accepted your friend request.</p>
</body>
</html>