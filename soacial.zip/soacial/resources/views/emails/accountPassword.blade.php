<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>SOACIAL Account Password</title>
</head>
<body>
<h1> Your Password</h1>
<p> {{ $plainPassword }} </p>
</body>
</html>