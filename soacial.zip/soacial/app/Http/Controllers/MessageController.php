<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Message;
use App\UsersInfo;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class MessageController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function inboxIndex()
    {
        $inboxFriends = User::join('messages', function ($join) {
            $join->on('users.id', '=', 'messages.from_id')
                ->orOn('users.id', '=','messages.to_id');
        })
            ->with(['approvedRequests','institutes','usersInfo' => function ($query) {
            $query->select('usersinfo.id','usersinfo.user_regno','usersinfo.avatar');
            }])
            ->select('users.id','users.reg_no', 'users.first_name', 'users.last_name', 'users.institute', 'users.gender',
                'users.created_at','users.verified','messages.seen')
            ->distinct()
            ->where(function ($query) {
                $query->where('messages.from_id',Auth::user()->id)
                    ->orWhere('messages.to_id',Auth::user()->id);
            })
            ->where('users.id','!=', Auth::user()->id)
            ->where('users.verified', 1)
            ->get();

        return view('inbox')
            ->with(['inboxFriends' => $inboxFriends]);
    }

    public function chatIndex(Request $request)
    {
        Validator::make($request->all(), [
            'regno'    => 'regex:/^[0-9]+$/',
        ])->validate();

        $chatUser = User::select('reg_no')->where('reg_no', $request->regno)->first();

        return view('chat')->with(['chatUser' => $chatUser]);
    }

    public function chatPost(Request $request)
    {
        Validator::make($request->all(), [
            'chat'    => 'required|string|max:1024|min:1',
            'regno'    => 'regex:/^[0-9]+$/',
        ])->validate();

        $user1 = Auth::user();
        $user2 = User::select('id')->where('reg_no',$request->regno)->first();

        $message = new Message;

        $message->from_id = $user1->id;
        $message->to_id = $user2->id;
        $message->chats = $request->chat;
        $message->save();

        return redirect()->back();

    }


}
